from __future__ import unicode_literals
from django.contrib import messages
from django.shortcuts import render, redirect, HttpResponse
from .models import User, Poke
from django.db.models import Q
import bcrypt


def index(request):
    # context = {"users": User.objects.all()}
    return render(request, 'index.html')

def register(request):
    #get user data from post request form
    result = User.objects.validate_registration(request.POST)

    #check for errors in registration validation and create messages / redirect users if so
    if type(result) == list:
        for err in result:
            messages.error(request, err)
        try:
            del request.session['user_id']
        except KeyError:
            pass

        return redirect(index)

    #if no errors in registration validation, redirect user to the welcome page & set post data
    request.session['user_id'] = result.id
    messages.success(request, "Successfully registered!")
    return redirect(dash)

def login(request):
    #get user data from post request form
    result = User.objects.validate_login(request.POST)

    #check for errors in login validation and create messages / redirect users if so
    if type(result) == list:
        for err in result:
            messages.error(request, err)
        return redirect(index)

    #if no errors in registration validation, redirect user to the welcome page & set post data
    request.session['user_id'] = result.id
    messages.success(request, "Successfully logged in!")
    return redirect(dash)

#logout user
def logout(request):
    if 'user_id' in request.session:
        del request.session['user_id']
    return redirect(index)


def dash(request):
    context = {
        'loggedin': User.objects.get(id=request.session['user_id']),
        'pokes': Poke.objects.all(),
        'users': User.objects.all().exclude(id=request.session['user_id']),
        'pokeNum': Poke.objects.all().count()
    }
    print'dashtest'
    return render(request, 'dash.html', context)

def createPoke(request):
    print '********** POKE is working ***********'
    print request.POST
    create = Poke.objects.createPoke(request.POST, request.session['user_id'])
    
    return redirect(dash)

def pokeResults(request, user_id):
    print"********* testing pokeResults *******"
    context = {
        'user': User.objects.all().get(id=user_id),
        'pokes': Poke.objects.all().filter(Q(poker=user_id) | Q(poked=user_id)).order_by('pokedate'),
    }
    return render(request, 'pokeExam_app/pokeresults.html', context)
